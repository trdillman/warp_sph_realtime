"""Per-scene simulation session (P1.1): every piece of runtime state behind start/stop/tick/dispose.

``addon.py`` is the Blender UI around it: operators, panels and the modal timer call these methods.
One ``SimSession`` exists per scene (``get(scene)``); at most one runs per process, because the solver,
its 1 ms timer and its viewport draw handler are process resources (``active()``).

CUDA-dependent bindings live in ``runtime`` and are filled only by ``addon._activate_runtime()``, the
single Warp import point. The sticky restart-required / interop-unavailable flags and the quarantine
are process-wide (``render.transport.process_state``) and outlive add-on reloads.
"""
from __future__ import annotations

import importlib
import logging
import time
from collections.abc import Callable

import bpy

from . import live_edits
from .props import spacing_metres, stiffness_pa
from .render import session as transport_session
from .render.gpu_points import settings_from_scene
from .render.transport import COMPLETED, FAILED, QUARANTINED, FatalTransportError, process_state
from .timeline import needs_step

_LOG = logging.getLogger(__name__)

# OpenGL display modes drawn from the GLInterop texture (session) path. SSFR and sphere impostors
# stay on the legacy raw-GL VBO path.
GL_TEXTURE_MODES = ("POINTS",)
_BACKEND_NAMES = {"VULKAN": "Vulkan", "OPENGL": "OpenGL"}

# SimSession.active_demo while an authored (tagged-object) scene runs; never a scene.warp_sph.demo_scene value.
CUSTOM_SCENE = "CUSTOM"

TIMER_INTERVAL_S = 0.001  # P0.5: 1 ms timer chosen by measured latency; do not change
BAKE_CHUNK_S = 0.004      # P2.2: most time one timer tick spends queueing bake frames (never a blocking loop)
BAKE_RING_SLOTS = 3       # frames in flight between the solver, the host copy and the disk writer
LIVE_CHUNK_S = 0.008     # host submission budget, checked between unchanged solver steps
LIVE_MAX_STEPS = 16      # never queue an unbounded timeline backlog in one publication

_QUARANTINE: list = process_state().quarantine  # objects never freed until exit, across reloads

Report = Callable[[set, str], object]  # Operator.report signature


class SceneSetupError(Exception):
    """The authored scene cannot be simulated as it stands (bad roles, geometry or spacing)."""


class Runtime:
    """CUDA-dependent bindings. Set only by ``addon._activate_runtime()``; ``wp`` is None until then."""
    wp = None
    ZeroCopyGLBuffer52 = None
    RealtimeWCSPHSolver = None
    build_blender_demo_helpers = None
    remove_blender_demo_helpers = None
    launch_demo_scene_init = None
    cleanup_viewport_renderer = None
    draw_particles_viewport = None


runtime = Runtime()


def gpu_backend() -> str:
    import gpu
    return gpu.platform.backend_type_get()


_device_total_mb: list[float] = []


def device_total_mb() -> float | None:
    """Total memory of the simulation GPU in MB, once Warp is loaded (read once: each query is a CUDA call).
    None before the first Start, after a fatal GPU error or if the query fails."""
    if _device_total_mb:
        return _device_total_mb[0]
    if runtime.wp is None or process_state().restart_required:
        return None
    try:
        _device_total_mb.append(runtime.wp.get_device("cuda:0").total_memory / 2**20)
    except Exception:
        return None
    return _device_total_mb[0]


def _scene_api():
    """NumPy-backed scene helpers (scene.blender_scene), imported on first use."""
    return importlib.import_module(".scene.blender_scene", __package__)


def _redraw_views(screen):
    for area in getattr(screen, "areas", ()):
        if area.type == 'VIEW_3D':
            area.tag_redraw()


def physics_changed(solver, settings) -> bool:
    """True when the solver's stiffness, CFL factor or viscosity differs from the scene settings."""
    return (solver.stiffness != stiffness_pa(settings) or solver.cfl_factor != settings.time_step_scale
            or solver.viscosity != settings.viscosity)


def apply_physics(solver, settings):
    """Copy the physics settings into the solver and re-derive dt. The caller recaptures the CUDA graph."""
    solver.stiffness = stiffness_pa(settings)
    solver.cfl_factor = settings.time_step_scale
    solver.viscosity = settings.viscosity
    solver.update_time_step()


class SimSession:
    """Runtime state of one scene's simulation. ``session`` is the render transport session
    (render/session.py; Vulkan/other backends and OpenGL Points), ``gl_buf`` the legacy OpenGL VBO
    (SSFR, spheres); at most one of the two is live."""

    def __init__(self, scene=None):
        self.scene = scene
        self.scene_uid = live_edits.uid(scene)
        self.gl_buf = None
        self.session: transport_session.TransportSession | None = None
        self.solver = None
        self.draw_handle = None
        self.timer = None
        self.token = 0             # bumped on every start/stop; orphaned modals exit
        self.running = False
        self.paused = False        # physics frozen; GPU state and drawing kept alive
        self.step_once = False     # advance exactly one frame while paused
        self.active_demo = "DOUBLE_DAM_PILLARS"
        self.fps_avg = 0.0
        self.frame_time_ms = 0.0
        self.vram_mb = 0.0
        self.step_count = 0
        self.last_tick = 0.0
        self.last_close = ""
        self.last_error = ""
        self.draw_errors: set = set()  # distinct draw failures already logged this run
        self.bake = None               # cache.bake.BakeJob while a bake runs (P2.2); driven by tick()
        self.bake_result = ""          # outcome of the last bake, for the panel
        # Interactive mode (P2.9): scene changes since the run was built, and the frame Reset returns to.
        self.tracker: live_edits.ChangeTracker | None = None
        self.start_frame: int | None = None
        self.last_reset_ms = 0.0
        self._output_pending = False  # a rebuilt solver still needs its initial frame published
        self._collider_uids: list = []   # animated colliders in solver order, by session_uid
        self._colliders: list = []       # the same, resolved to objects (None once removed)
        self._held: dict = {}            # index -> last pose of each animated collider

    # Process-lifetime flags: they outlive add-on disable/enable (module reload).
    @property
    def restart_required(self) -> str:  # fatal GPU/CUDA state: no further CUDA work this process
        return process_state().restart_required

    @restart_required.setter
    def restart_required(self, value: str):
        process_state().restart_required = value

    @property
    def interop_unavailable(self) -> str:  # recoverable interop failure: Readback until restart
        return process_state().interop_unavailable

    @interop_unavailable.setter
    def interop_unavailable(self, value: str):
        process_state().interop_unavailable = value

    # -- state queries -------------------------------------------------------------------------------

    def readback_active(self) -> bool:
        """True while Readback runs on a backend where OpenGL would help (from what runs, not prefs)."""
        session = self.session
        return session is not None and session.backend != 'OPENGL' and not session.transport.capabilities().zero_copy

    def gl_uses_texture(self, scene) -> bool:
        """OpenGL route, fixed for a run: chosen from the display mode at Start, kept through resizes."""
        if self.session is not None or self.gl_buf is not None:
            return self.session is not None
        if self.interop_unavailable:
            # The texture interop failed earlier this process: the legacy VBO interop (no CPU copy)
            # beats Readback, and was the only OpenGL route before the texture adapter.
            return False
        return scene.warp_sph.render_mode in GL_TEXTURE_MODES

    # -- viewport draw -------------------------------------------------------------------------------

    def draw(self):
        """SpaceView3D POST_VIEW callback; never raises into Blender."""
        job = getattr(self, 'native_bake', None)
        session = job.bridge if job is not None else self.session
        try:
            if session is None:
                # Legacy OpenGL path: the SSFR/sphere passes restore GL state in a finally block
                # (_preserve_gl_state) and draw_points restores its own, so a failure leaves none behind.
                runtime.draw_particles_viewport(self.gl_buf, self.running)
                return
            scene = bpy.context.scene
            snapshot_pending = getattr(session, 'snapshot_status', '') == 'QUEUED'
            if not self.running or (not scene.warp_sph.show_particles and not snapshot_pending):
                return
            session.draw(settings_from_scene(scene, session.backend))
        except FatalTransportError as exc:
            self.mark_fatal(str(exc))
        except Exception as exc:
            self._report_draw_failure(exc)

    def _report_draw_failure(self, exc: Exception):
        """Stop the run and log each distinct draw failure once, never once per redraw."""
        self.last_error = f"Viewport draw failed: {exc}"
        self.running = False  # the modal timer stops the session; never raise every redraw
        key = f"{type(exc).__name__}: {exc}"
        if key not in self.draw_errors:
            self.draw_errors.add(key)
            _LOG.error("WarpSPH viewport draw failed (logged once per distinct error): %s", key, exc_info=exc)

    # -- failure handling ----------------------------------------------------------------------------

    def mark_fatal(self, reason: str):
        self.restart_required = self.restart_required or reason
        self.running = False

    def _retire(self, session):
        result = session.close()
        self.last_close = result
        if result != COMPLETED:
            _QUARANTINE.append(session)
        if result == QUARANTINED:  # Blender objects retained: do not create more interop objects
            self.interop_unavailable = self.interop_unavailable or \
                f"{_BACKEND_NAMES.get(session.backend, session.backend)} interop cleanup was quarantined (no GPU-context route)"
        if result == FAILED:
            self.mark_fatal(session.fatal_reason or "transport cleanup did not complete; ownership retained")

    # -- solver and output allocation ----------------------------------------------------------------

    def _custom_solver(self, scene, depsgraph):
        """Solver for the tagged objects; the particle count is the fill at the scene's spacing, or the
        Max Particles budget when the scene has emitters."""
        from .scene.description import SceneFillError, SceneValidationError
        try:
            desc = _scene_api().description_from_blender(scene, depsgraph)
            settings = scene.warp_sph
            from .cache.provenance import scene_provenance
            spacing = spacing_metres(settings, _scene_api().unit_scale(scene))
            solver = runtime.RealtimeWCSPHSolver.from_scene(
                desc, spacing, substeps=settings.substeps,
                stiffness=stiffness_pa(settings), cfl_factor=settings.time_step_scale,
                viscosity=settings.viscosity)
            solver._cache_initial_provenance = scene_provenance(desc, spacing=spacing)
            return solver
        except (SceneValidationError, SceneFillError) as exc:
            raise SceneSetupError(str(exc)) from exc

    def _new_solver(self, scene, num_p: int, demo_type: str, depsgraph=None):
        if demo_type == CUSTOM_SCENE:
            return self._custom_solver(
                scene, depsgraph if depsgraph is not None else bpy.context.evaluated_depsgraph_get())
        settings = scene.warp_sph
        solver = runtime.RealtimeWCSPHSolver(
            num_particles=num_p,
            h=0.04,
            substeps=settings.substeps,
            enable_obstacles=0,  # the demos set a scene: their obstacles are mesh colliders
        )
        solver.stiffness = stiffness_pa(settings)
        solver.cfl_factor = settings.time_step_scale
        solver.viscosity = settings.viscosity
        # Initialize GPU SoA particle distribution for the chosen demo
        runtime.launch_demo_scene_init(solver, demo_type)
        solver.rebuild_cuda_graph()
        return solver

    def reallocate(self, scene, num_p: int, demo_type: str, window=None, depsgraph=None, keep_output=False):
        """Transactional: the new output and solver are built while the old ones stay live;
        on failure the new ones are released and the running session is untouched.

        demo_type CUSTOM_SCENE builds the authored scene from tagged objects; num_p is then ignored and
        every output is sized from the solver's fill count. ``keep_output`` (Reset) keeps the current
        output when the new solver has the same particle count: no transport or renderer is rebuilt."""
        backend = gpu_backend()
        shared_sdk = (getattr(self.session, 'is_shared_sdk', False) if self.session is not None
                      else bool(getattr(scene.warp_sph, 'use_shared_sdk', False)))
        uses_vbo = not shared_sdk and backend == 'OPENGL' and not self.gl_uses_texture(scene)
        solver = None
        if keep_output and (self.gl_buf if uses_vbo else self.session) is not None:
            solver = self._new_solver(scene, num_p, demo_type, depsgraph)
        if solver is not None and self._reuse_output(solver, uses_vbo):
            self.solver, self.active_demo = solver, demo_type
        elif uses_vbo:
            # An authored scene's particle count is known only after the fill, so its solver comes first.
            if solver is None and demo_type == CUSTOM_SCENE:
                solver = self._new_solver(scene, num_p, demo_type, depsgraph)
            gl_buf = runtime.ZeroCopyGLBuffer52(solver.num_particles if solver is not None else num_p)
            try:
                if solver is None:
                    solver = self._new_solver(scene, num_p, demo_type)
                with gl_buf.mapped() as pos_vbo_wp:
                    solver.copy_positions(pos_vbo_wp)
            except BaseException:
                gl_buf.destroy()
                raise
            # Commit point: output and solver switch together, before the old output is released.
            old_buf, self.gl_buf = self.gl_buf, gl_buf
            self.solver, self.active_demo = solver, demo_type
            if old_buf:
                old_buf.destroy()
            self._output_pending = False
        else:
            if solver is None:
                solver = self._new_solver(scene, num_p, demo_type, depsgraph)
            window = window or bpy.context.window
            try:
                if shared_sdk:
                    from .interop_bridge import open_session as open_sdk_session
                    session = open_sdk_session(solver, scene, window.as_pointer())
                else:
                    session = transport_session.open_session(
                        backend, solver.num_particles, window.as_pointer(), interop_unavailable=self.interop_unavailable)
            except FatalTransportError:
                _QUARANTINE.append(solver)
                raise
            try:
                output_pending = not session.tick(solver.copy_positions)  # retry if the output is busy
            except FatalTransportError:
                _QUARANTINE.extend((solver, session))  # no CUDA cleanup after a fatal error
                raise
            except BaseException:
                self._retire(session)
                if self.restart_required:  # its cleanup failed: CUDA state unknown, keep the solver too
                    _QUARANTINE.append(solver)
                raise
            zero_copy = session.transport.capabilities().zero_copy
            old_session, old_solver = self.session, self.solver
            if backend in _BACKEND_NAMES and not zero_copy:
                if old_session is not None and old_session.transport.capabilities().zero_copy:
                    # A resize must not silently downgrade a working interop session.
                    self._retire(session)
                    if self.restart_required:
                        _QUARANTINE.append(solver)
                        raise FatalTransportError(self.restart_required)
                    raise RuntimeError(
                        f"new size cannot use {_BACKEND_NAMES[backend]} interop ({session.reason}); kept the current size")
                self.interop_unavailable = session.reason  # fall back once; no interop retries
            # Commit point: output and solver switch together, before the old session is retired.
            self.session = session
            self.solver, self.active_demo = solver, demo_type
            self._output_pending = output_pending
            if old_session is not None:
                self._retire(old_session)
                if self.restart_required:  # old cleanup failed: stop; stop() quarantines the new pair
                    _QUARANTINE.append(old_solver)
                    raise FatalTransportError(self.restart_required)

        self.vram_mb = self.solver.get_vram_usage_mb()
        self.step_count = 0
        self.last_tick = 0.0
        self._rebase(scene)
        if demo_type == CUSTOM_SCENE:
            if runtime.remove_blender_demo_helpers is not None:
                runtime.remove_blender_demo_helpers()  # demo wireframes would only confuse an authored scene
        else:
            # Spawn matching Blender 3D viewport wireframe domain & obstacle collider meshes
            runtime.build_blender_demo_helpers(demo_type)

    def _reuse_output(self, solver, uses_vbo: bool) -> bool:
        """Reset with an unchanged particle count: the new solver publishes through the current output, so no
        transport, interop buffer or renderer is rebuilt. False when the count differs (a new output is built)."""
        count = solver.num_particles
        if uses_vbo:
            if getattr(self.gl_buf, "num_particles", None) != count:
                return False
            with self.gl_buf.mapped() as pos_vbo_wp:
                solver.copy_positions(pos_vbo_wp)
            self._output_pending = False
            return True
        session = self.session
        if session is None or session.count != count:
            return False
        if getattr(session, 'is_shared_sdk', False) and not session.try_bind_solver(solver):
            return False
        try:
            self._output_pending = not session.tick(solver.copy_positions)
        except FatalTransportError:
            _QUARANTINE.append(solver)
            raise
        return True

    # -- interactive mode (P2.9) -----------------------------------------------------------------

    def _rebase(self, scene):
        """The run was just built from ``scene`` as it is now: nothing is pending, and this is its start frame."""
        self.start_frame = int(getattr(scene, "frame_current", 1))
        self._timeline_target = self.start_frame
        self._timeline_elapsed = 0.0
        render = getattr(scene, 'render', None)
        # Scene construction accepts this rate. Demo solvers keep a legacy
        # hardcoded fps field, so it is not authority for the timeline clock.
        self._timeline_fps = float(render.fps / render.fps_base) if render is not None else None
        self._timeline_playing = False
        self._timeline_seek_pending = False
        self._timeline_pause_requested = False
        self._timeline_step_requested = False
        self._timeline_reset_failed = False
        self._timeline_rebuild = False
        self.timeline_status = "Timeline ready: Play or move the playhead"
        self.tracker = live_edits.ChangeTracker(scene, custom=self.active_demo == CUSTOM_SCENE)
        if getattr(self.session, 'is_shared_sdk', False):
            self.session.note_scene_applied()
        names = list(getattr(self.solver, "animated_collider_names", ()) or ()) if self.active_demo == CUSTOM_SCENE else []
        if names:
            by_name = {obj.name: obj for obj in scene.objects}
            objs = [by_name.get(n) for n in names]
        else:
            objs = []
        self._collider_uids = [live_edits.uid(o) if o is not None else None for o in objs]
        self._colliders = objs
        # Start-frame poses: a collider deleted before its first sync still has a pose to hold.
        matrix = _scene_api()._matrix_or_none
        self._held = {i: m for i, m in enumerate(matrix(o) for o in objs) if m is not None}

    def _resolve_objects(self):
        """Re-find the animated colliders by session_uid (after undo / redo); a missing one is None."""
        if not self._collider_uids:
            return
        by_uid = live_edits.objects_by_uid(self.scene)
        self._colliders = [by_uid.get(key) for key in self._collider_uids]

    def note_updates(self, updates=()):
        """depsgraph_update_post while this run is active: mark changes, no GPU work."""
        if self.tracker is not None:
            self.tracker.note_updates(updates)

    def pending_gravity(self):
        """The scene gravity (m/s^2) to apply live, or None."""
        tracker = self.tracker
        if self.active_demo != CUSTOM_SCENE or tracker is None or "gravity" not in tracker.pending:
            return None
        return tracker.current.settings["gravity"]

    def reset_reasons(self) -> list[str]:
        return self.tracker.reset_reasons() if self.tracker is not None else []

    def _set_frame(self, frame):
        """Move the playhead (not a user edit: the tracker is muted)."""
        tracker = self.tracker
        if tracker is not None:
            with tracker.muted():
                self.scene.frame_set(frame)
        else:
            self.scene.frame_set(frame)

    def _rebuild_at_start(self, context, start=None):
        """Rebuild solver and output from the scene at ``start`` (default: the run's start frame), which becomes
        the run's start frame. Transactional (see reallocate): on failure the playhead is put back too."""
        scene = self.scene
        settings = scene.warp_sph
        if settings.scene_source == 'CUSTOM':
            start = self.start_frame if start is None else start
            frame = getattr(scene, "frame_current", None)
            if start is not None and frame is not None and frame != start:
                self._set_frame(start)
            try:
                self.reallocate(scene, 0, CUSTOM_SCENE, context.window,
                                depsgraph=context.evaluated_depsgraph_get(), keep_output=True)
            except BaseException:
                if frame is not None and getattr(scene, "frame_current", frame) != frame:
                    self._set_frame(frame)
                raise
        else:
            frame = getattr(scene, "frame_current", None)
            start = self.start_frame if start is None else start
            if frame is not None and start is not None:
                self._set_frame(start)
            try:
                self.reallocate(scene, settings.particle_count, settings.demo_scene, context.window, keep_output=True)
            except BaseException:
                if frame is not None:
                    self._set_frame(frame)
                raise

    def reset(self, context, report: Report) -> bool:
        """Restart the running simulation at its start frame with every scene edit applied, keeping the Warp
        runtime, the timer and the draw handler. A scene that cannot be built keeps the current run."""
        if not self.running or self.solver is None:
            report({'ERROR'}, "Start the simulation before Reset")
            return False
        if self.bake is not None or getattr(self, 'native_bake', None) is not None:
            report({'ERROR'}, "Cancel the bake before Reset")
            return False
        t0 = time.perf_counter()
        try:
            self._rebuild_at_start(context)  # puts the playhead back if the scene cannot be built
        except FatalTransportError as exc:
            self.mark_fatal(str(exc))
            report({'ERROR'}, f"WarpSPH GPU transport failed; restart Blender: {exc}")
            return False
        except Exception as exc:  # SceneSetupError and other build errors: the current run continues
            report({'ERROR'}, f"WarpSPH cannot reset: {exc}; the current run continues")
            return False
        self.last_reset_ms = (time.perf_counter() - t0) * 1000.0
        self.step_once = False
        report({'INFO'}, f"WarpSPH reset to frame {self.start_frame} ({self.last_reset_ms:.0f} ms)")
        return True

    def after_undo(self):
        """undo_post / redo_post: undo swaps in an earlier copy of the file's data, so find the run's scene and
        objects again by session_uid. A scene that no longer exists stops the run."""
        scene = _find_scene(self.scene_uid)
        if scene is None:
            self.stop()
            self.last_error = "Stopped: undo removed the simulated scene"
            return
        old_key = next((k for k, s in _SESSIONS.items() if s is self), None)
        self.scene = scene
        new_key = _scene_key(scene)
        if old_key is not None and old_key != new_key:
            del _SESSIONS[old_key]
            _SESSIONS[new_key] = self
        self._resolve_objects()
        if self.tracker is not None:
            self.tracker.after_undo()  # re-read everything the undo may have changed

    def apply_scene(self, context, count: int, demo: str, report: Report) -> bool:
        """Resize or switch demo while running; on failure the running session is kept and the
        scene settings are put back so the same change is not retried every tick."""
        frame = self.scene.frame_current if hasattr(context.screen, 'is_animation_playing') else None
        try:
            if frame is not None:
                self._set_frame(self.start_frame)
            self.reallocate(self.scene, count, demo, context.window)
            return True
        except FatalTransportError as exc:
            self.mark_fatal(str(exc))
            report({'ERROR'}, f"WarpSPH GPU transport failed; restart Blender: {exc}")
        except Exception as exc:
            report({'ERROR'}, f"WarpSPH could not rebuild the scene: {exc}")
            if self.solver is not None:  # keep the running session; do not retry the same change
                settings = self.scene.warp_sph
                if self.active_demo == CUSTOM_SCENE:
                    settings.scene_source = 'CUSTOM'
                else:
                    settings.particle_count = self.solver.num_particles
                    settings.demo_scene = self.active_demo
        finally:
            if frame is not None:
                self._set_frame(frame)
        return False

    # -- lifecycle -----------------------------------------------------------------------------------

    def start(self, context, report: Report, activate: Callable[[], None]) -> int | None:
        """Build the solver and output for ``context.scene``, then add the draw handler and 1 ms timer.

        Returns the run token for the modal operator, or None after reporting why it could not start
        (nothing is left behind). ``activate`` is ``addon._activate_runtime`` (the Warp import point)."""
        if self.restart_required:
            report({'ERROR'}, f"WarpSPH needs a Blender restart: {self.restart_required}")
            return None
        self.scene = context.scene
        self.scene_uid = live_edits.uid(context.scene)
        self.last_error = ""
        self.draw_errors.clear()
        initial_frame = getattr(self.scene, 'frame_current', None)
        if hasattr(context.screen, 'is_animation_playing'):
            self._set_frame(self.scene.frame_start)
        try:
            if getattr(self.scene.warp_sph, 'use_shared_sdk', False):
                from .sdk_dependency import validate_environment
                from .warp_installer import ensure_installed_warp_on_path
                ensure_installed_warp_on_path()  # admit the configured source before locating the SDK
                validate_environment()  # identity/backend admission before allocating the real solver
            activate()
            scene = self.scene
            settings = scene.warp_sph
            if settings.scene_source == 'CUSTOM':
                self.reallocate(scene, 0, CUSTOM_SCENE, context.window, depsgraph=context.evaluated_depsgraph_get())
            else:
                self.reallocate(scene, settings.particle_count, settings.demo_scene, context.window)
        except SceneSetupError as exc:
            if initial_frame is not None:
                self._set_frame(initial_frame)
            self.stop(context)
            self.last_error = f"Scene not valid: {exc}"
            report({'ERROR'}, f"WarpSPH cannot start this scene: {exc}")
            return None
        except FatalTransportError as exc:
            if initial_frame is not None:
                self._set_frame(initial_frame)
            self.mark_fatal(str(exc))
            self.stop(context)
            report({'ERROR'}, f"WarpSPH GPU transport failed; restart Blender: {exc}")
            return None
        except Exception as exc:
            if initial_frame is not None:
                self._set_frame(initial_frame)
            self.stop(context)
            report({'ERROR'}, f"WarpSPH cannot start: {exc}")
            return None

        self.running = True
        self.paused = False
        self.step_once = False
        self.token += 1
        try:
            self.draw_handle = bpy.types.SpaceView3D.draw_handler_add(self.draw, (), 'WINDOW', 'POST_VIEW')
            self.timer = context.window_manager.event_timer_add(TIMER_INTERVAL_S, window=context.window)
        except Exception as exc:
            self.stop(context)
            report({'ERROR'}, f"WarpSPH cannot start: {exc}")
            return None
        _watch_depsgraph(True)
        return self.token

    def tick(self, context, report: Report) -> bool:
        """One timer event. Returns False when the run ended here (the session is already stopped)."""
        screen = context.screen
        if screen is None or not any(area.type == 'VIEW_3D' for area in screen.areas):
            report({'WARNING'}, "WarpSPH stopped: its window has no 3D viewport")
            self.stop(context)
            return False
        try:
            settings = self.scene.warp_sph
            target_count = settings.particle_count
            target_demo = settings.demo_scene
        except ReferenceError:  # the scene was deleted under the run
            report({'WARNING'}, "WarpSPH stopped: its scene was removed")
            self.stop(context)
            return False

        if getattr(self.session, 'is_shared_sdk', False):
            self.session.scene = self.scene
            from . import native_output
            if getattr(bpy.app, 'is_job_running', lambda kind: False)('RENDER'):
                return True
            # Main-thread mutation stays outside draw. Pace automatic captures
            # against completed simulation frames while the timeline plays.
            native_output.service(self, timeline_playing=bool(getattr(screen, 'is_animation_playing', False)))
            if getattr(self, 'native_bake', None) is not None:
                return self.native_bake.tick(context, report)
        if self.tracker is not None:
            self.tracker.refresh(self.scene)  # re-reads the scene only after Blender reported a change
        if self.bake is not None:  # a bake owns the solver: live edits apply when it ends
            return self._tick_bake(context, report, screen)
        gravity = self.pending_gravity()

        # Dynamic Buffer & Demo Manager: reallocate/reset on-the-fly if slider or demo changed.
        # An authored scene's object and spacing changes apply on Reset (live_edits.EDITS).
        if self.active_demo != CUSTOM_SCENE and (
                self.solver.num_particles != target_count or self.active_demo != target_demo):
            if not self.apply_scene(context, target_count, target_demo, report):
                if not self.running:
                    self.stop(context)
                    return False
                _redraw_views(screen)  # kept the running session; no step this tick
                return True
        elif gravity is not None or physics_changed(self.solver, settings):
            try:
                # Stiffness, time step, viscosity and gravity are captured by value: recapture the graph (no
                # allocation; the same path the stiffness slider has always used).
                if physics_changed(self.solver, settings):
                    apply_physics(self.solver, settings)
                if gravity is not None:
                    self.solver.gravity = runtime.wp.vec3(*gravity)
                self.solver.rebuild_cuda_graph()
                if gravity is not None:
                    self.tracker.accept("gravity")
                if getattr(self.session, "is_shared_sdk", False):
                    self.session.note_scene_applied()
            except Exception as exc:
                if self.session is not None:  # as a failed step (session.tick): CUDA state unknown
                    self.mark_fatal(f"CUDA graph rebuild failed; CUDA state unknown: {exc}")
                    report({'ERROR'}, f"WarpSPH GPU transport failed; restart Blender: {exc}")
                else:
                    report({'ERROR'}, f"WarpSPH stopped: {exc}")
                self.stop(context)
                return False

        if self._output_pending and self.session is not None:
            try:
                self._output_pending = not self.session.tick(self.solver.copy_positions)
            except FatalTransportError as exc:
                self.mark_fatal(str(exc))
                report({'ERROR'}, f"WarpSPH GPU transport failed; restart Blender: {exc}")
                self.stop(context)
                return False
            except Exception as exc:
                report({'ERROR'}, f"WarpSPH stopped: {exc}")
                self.stop(context)
                return False
            _redraw_views(screen)
            return True  # publish the initial state before advancing, including when paused

        timeline_bound = hasattr(screen, 'is_animation_playing')
        step_seconds = 0.0
        fps, target = 0.0, self.start_frame  # batch timing is used only with a native timeline
        if timeline_bound:
            if getattr(self, '_timeline_reset_failed', False):
                if screen.is_animation_playing:
                    bpy.ops.screen.animation_cancel(restore_frame=False)
                self.paused = True
                self.timeline_status = "Timeline rebuild failed: fix the scene, then Reset"
                _redraw_views(screen)
                return True
            target = max(self.start_frame, int(self.scene.frame_current))
            if self.scene.frame_current < self.start_frame:
                self._set_frame(self.start_frame)
            previous = getattr(self, '_timeline_target', self.start_frame)
            playing = bool(screen.is_animation_playing)
            was_playing = getattr(self, '_timeline_playing', False)
            seek_pending = getattr(self, '_timeline_seek_pending', False)
            pause_requested = getattr(self, '_timeline_pause_requested', False)
            self._timeline_pause_requested = False
            step_requested = getattr(self, '_timeline_step_requested', False)
            self._timeline_step_requested = False
            if step_requested:
                seek_pending = True
            elif not playing and (was_playing or pause_requested) and target != self.start_frame:
                # Pause is cancellation, not permission to drain a backlog of
                # future solver steps. A final playback frame may arrive with it.
                seek_pending = False
            elif target != previous:
                seek_pending = not playing
            after_bake = getattr(self, '_timeline_rebuild', False)
            if after_bake:
                seek_pending = True
            if after_bake and screen.is_animation_playing:
                bpy.ops.screen.animation_cancel(restore_frame=False)
                playing = False
            if target < previous or after_bake:
                # Without recorded inputs a seek replays the current settings.
                # Rebuild transactionally, then catch up in bounded modal ticks.
                requested = target
                if not self.reset(context, report):
                    self._timeline_reset_failed = True
                    self._timeline_rebuild = True  # failed replay remains required
                    if screen.is_animation_playing:
                        bpy.ops.screen.animation_cancel(restore_frame=False)
                    self.paused = True
                    return True
                self._set_frame(requested)
                self._timeline_rebuild = False
                target = requested
                report({'INFO'}, "Timeline rewind: replaying from start with current settings")
            self._timeline_target = target
            self._timeline_playing = playing
            self._timeline_seek_pending = seek_pending
            self.paused = not playing
            if not playing and not seek_pending:
                elapsed = getattr(self, '_timeline_elapsed', 0.0)
                self.timeline_status = f"Paused: playhead {target}, simulated {elapsed:.3f} s"
                _redraw_views(screen)
                return True
            fps = self._timeline_fps or self.scene.render.fps / self.scene.render.fps_base
            step_seconds = float(self.solver.dt) * int(settings.substeps)
            try:
                pending = needs_step(target, self.start_frame, fps,
                                     getattr(self, '_timeline_elapsed', 0.0), step_seconds)
            except ValueError as exc:
                message = str(exc)
                if self.timeline_status != message:
                    report({'WARNING'}, message)
                self.timeline_status = message
                if screen.is_animation_playing:
                    bpy.ops.screen.animation_cancel(restore_frame=False)
                self.paused = True
                _redraw_views(screen)
                return True
            if not pending:
                self._timeline_seek_pending = False
                self.step_once = False
                self.timeline_status = f"Timeline frame {target}: ready"
                _redraw_views(screen)
                return True
            self.timeline_status = f"Simulating toward timeline frame {target}"
        elif self.paused and not self.step_once:
            _redraw_views(screen)  # keep redrawing so display settings stay live on the frozen frame
            return True

        t0 = time.perf_counter()

        self.solver.substeps = settings.substeps
        solver, use_graph = self.solver, settings.use_cuda_graph
        taken = 0

        def produce(out):
            nonlocal taken
            # Admission belongs to the transport. Once admitted, amortize output
            # over at most one timeline frame (plus <one step of rounding), with
            # hard step and host-time caps so input events regain control.
            begin = time.perf_counter()
            elapsed = getattr(self, '_timeline_elapsed', 0.0)
            while True:
                if self.active_demo == CUSTOM_SCENE:
                    # Sampling covers only the next solver step's interval.
                    frame = self.scene.frame_current if timeline_bound else None
                    try:
                        self._sync_colliders(solver)
                    finally:
                        if frame is not None and self.scene.frame_current != frame:
                            self._set_frame(frame)
                    if getattr(self.session, 'is_shared_sdk', False):
                        self.session.note_scene_applied()
                solver.step(out, use_graph=use_graph)
                taken += 1
                if not timeline_bound or taken >= LIVE_MAX_STEPS:
                    break
                if (taken * step_seconds + 1e-10 >= 1.0 / fps
                        or time.perf_counter() - begin >= LIVE_CHUNK_S
                        or not needs_step(target, self.start_frame, fps,
                                          elapsed + taken * step_seconds, step_seconds)):
                    break

        try:
            if self.session is not None:
                # No host sync: the adapter orders publication on the solver stream and
                # skips the step (backpressure) while a step is in flight or both slots are busy.
                stepped = self.session.tick(produce)
            else:
                with self.gl_buf.mapped() as pos_vbo_wp:
                    produce(pos_vbo_wp)
                runtime.wp.synchronize_device("cuda:0")
                stepped = True
        except FatalTransportError as exc:
            self.mark_fatal(str(exc))
            report({'ERROR'}, f"WarpSPH GPU transport failed; restart Blender: {exc}")
            self.stop(context)
            return False
        except Exception as exc:
            report({'ERROR'}, f"WarpSPH stopped: {exc}")
            self.stop(context)
            return False
        now = time.perf_counter()
        if self.session is None:
            dt_ms = (now - t0) * 1000.0 / max(taken, 1)
        elif taken and self.last_tick:
            dt_ms = (now - self.last_tick) * 1000.0 / max(taken, 1)  # wall-clock per solver step
        else:
            dt_ms = None
        if taken and self.session is not None:
            self.last_tick = now
        if dt_ms is not None:
            self.frame_time_ms = 0.9 * self.frame_time_ms + 0.1 * dt_ms if self.step_count > 0 else dt_ms
            self.fps_avg = 1000.0 / max(self.frame_time_ms, 0.001)
        if taken:
            self.step_count += taken
            if timeline_bound:
                self._timeline_elapsed = getattr(self, '_timeline_elapsed', 0.0) + taken * step_seconds
            self.step_once = False  # a single-step request survives a backpressure skip
            # A transport may admit compute then defer its final publication.
            # Retain the advanced clock and retry output without repeating physics.
            self._output_pending = not stepped
        if getattr(solver, "emission_exhausted", False) and solver.take_exhaustion_notice():
            report({'WARNING'}, "WarpSPH: particle budget reached; emitters stopped (raise Max Particles)")

        # GL draws synchronously after every step; a session redraws only for a new frame
        if self.session is None or self.session.take_new_frame():
            _redraw_views(screen)
        return True

    def _sync_colliders(self, solver):
        tracker = self.tracker
        if tracker is None:
            _scene_api().sync_collider_keyframes(self.scene, solver)
            return
        with tracker.muted():  # its frame_set is not a user edit
            _scene_api().sync_collider_keyframes(self.scene, solver, objects=self._colliders, held=self._held)

    # -- bake (P2.2) ---------------------------------------------------------------------------------

    def begin_bake(self, context, report: Report, *, first: int, last: int, resume: bool) -> bool:
        """Bake frames ``first`` ... ``last`` of the running scene into its cache folder, driven by ``tick``.

        Fresh bakes start from the scene's initial state; resume continues after the last intact cached frame.
        Returns False after reporting why nothing started (or that everything is already cached)."""
        from .cache import bake as cache_bake
        from .cache import blender_adapter
        from .cache import disk as cache_disk
        from .cache.frame_store import FrameStore
        from .cache.gpu import SolverSource, VramRing
        from .cache.provenance import capture_scene, feed_motion, scene_provenance

        if not self.running or self.solver is None or runtime.wp is None:
            report({'ERROR'}, "Start the simulation before baking")
            return False
        if getattr(self.session, 'is_shared_sdk', False):
            from .native_output import begin_bake
            return begin_bake(self, context, report, first=first, last=last, resume=resume)
        if self.bake is not None:
            report({'ERROR'}, "A bake is already running")
            return False
        scene = self.scene
        settings = scene.warp_sph
        fps = scene.render.fps / scene.render.fps_base
        try:
            # Frame ``first`` is the initial state at the solver's start frame: emitters and animated colliders run
            # on that clock, so an authored scene built at another frame (the playhead at Start) is rebuilt there.
            # BakeJob advances the solver without updating the live-preview step counter, so advanced state is
            # reset even for an empty/interrupted Resume before restoring a prefix.
            custom = self.active_demo == CUSTOM_SCENE
            advanced = self.step_count > 0 or getattr(self.solver, "sim_time", 0.0) > 0.0
            if (custom and self.start_frame != first) or advanced:
                self.paused = False
                self._rebuild_at_start(context, first if custom else None)
            solver = self.solver
            apply_physics(solver, settings)
            solver.rebuild_cuda_graph()
            steps = cache_bake.steps_per_frame(settings.bake_steps, solver.dt, fps)
            motion_keys = {}
            if self.active_demo == CUSTOM_SCENE:
                spacing = spacing_metres(settings, _scene_api().unit_scale(scene))
                initial, provenance, motion_keys = capture_scene(
                    scene, context.evaluated_depsgraph_get(), first=first, last=last,
                    steps=steps, dt=solver.dt, spacing=spacing)
                if initial != getattr(solver, "_cache_initial_provenance", None):
                    raise ValueError(
                        "scene inputs differ from the initialized solver; restart the simulation "
                        "at the bake start frame before Bake Cache or Resume")
            else:
                from .scene.demo_description import demo_description, demo_spacing
                provenance = scene_provenance(
                    demo_description(self.active_demo, solver.num_particles),
                    spacing=demo_spacing(solver.num_particles),
                    initializer={"demo": self.active_demo, "particles": solver.num_particles, "version": 1})
            signature = cache_bake.solver_signature(
                solver, steps, fps, scene_name(scene), self.active_demo, provenance=provenance)
            disk = cache_disk.DiskCache(blender_adapter.cache_dir(scene))
            remaining = max(last - first + 1 - (disk.cached_count() if resume else 0), 0)
            free = cache_disk.free_bytes(disk.directory)
            need = cache_disk.estimate_bytes(solver.num_particles, remaining)
            if free is not None and need > free:
                report({'ERROR'}, f"Not enough disk space in {disk.directory}: the bake needs about "
                                  f"{need / 2**30:.1f} GB, {free / 2**30:.1f} GB free")
                return False
            # With emitters a frame holds the active particles (up to the pool): restore_state checks the count.
            particles = None if getattr(solver, "has_emitters", False) else solver.num_particles
            plan = cache_bake.plan_bake(disk, signature, first, last, resume=resume, particles=particles)
            if plan.complete:
                report({'INFO'}, f"Frames {first}-{last} are already cached")
                return False
            ring = VramRing(runtime.wp, solver.num_particles, BAKE_RING_SLOTS)  # the pool: emitters never overflow it
            store = FrameStore(disk, ring)
            before_step = None
            if motion_keys:
                # A live preview may have cached keys from before this snapshot. Reload all keys
                # from frozen provenance rather than retaining any mutable preview authority.
                solver._key_frames.clear()

                def feed_frozen_motion(scene=scene, solver=solver, keys=motion_keys):
                    feed_motion(scene, solver, keys)

                before_step = feed_frozen_motion
            elif self.active_demo == CUSTOM_SCENE:  # animated colliders: one transform read per frame, as in tick
                def sync_live_colliders(solver=solver):
                    self._sync_colliders(solver)

                before_step = sync_live_colliders
            try:
                self.bake = cache_bake.BakeJob(
                    store, SolverSource(runtime.wp, solver, steps, settings.use_cuda_graph,
                                        before_step=before_step, first_frame=first), plan)
            except BaseException:
                store.close()
                raise
        except FatalTransportError as exc:
            self.mark_fatal(str(exc))
            report({'ERROR'}, f"WarpSPH GPU transport failed; restart Blender: {exc}")
            return False
        except Exception as exc:  # CacheError, CacheMismatchError, ValueError (resume mismatch), solver errors
            report({'ERROR'}, f"WarpSPH cannot bake: {exc}")
            return False
        self.bake_result = ""
        self.paused = False
        self.step_once = False
        return True

    def cancel_bake(self):
        """Stop capturing; frames already queued are still written, so the cache stays a whole prefix."""
        if getattr(self, 'native_bake', None) is not None:
            self.native_bake.cancelled = True
        if self.bake is not None:
            self.bake.cancel()

    def _publish_solver(self):
        """Show the solver's latest state in the viewport (the bake bypasses the normal step path).

        ``copy_positions`` writes scene units, as ``step()`` does (the solver works in metres)."""
        wp, solver = runtime.wp, self.solver
        if self.session is not None:
            self.session.tick(solver.copy_positions)
        elif wp.get_stream("cuda:0").is_complete:  # the legacy VBO route waits for the GPU: only when idle
            with self.gl_buf.mapped() as pos_vbo_wp:
                solver.copy_positions(pos_vbo_wp)
            wp.synchronize_device("cuda:0")

    def _tick_bake(self, context, report: Report, screen) -> bool:
        bake = self.bake
        done_before = bake.frames_done
        try:
            if bake.run_chunk(BAKE_CHUNK_S):
                self._publish_solver()
        except FatalTransportError as exc:
            self.mark_fatal(str(exc))
            report({'ERROR'}, f"WarpSPH GPU transport failed; restart Blender: {exc}")
            self.stop(context)
            return False
        except Exception as exc:  # the solver step or a Warp copy failed
            if self.session is not None:  # as a failed step (session.tick): CUDA state unknown
                self.mark_fatal(f"bake step failed; CUDA state unknown: {exc}")
                report({'ERROR'}, f"WarpSPH GPU transport failed; restart Blender: {exc}")
            else:
                report({'ERROR'}, f"WarpSPH bake stopped: {exc}")
            self.stop(context)
            return False
        finished = not bake.active
        if finished:
            self._finish_bake(report)
        if finished or bake.frames_done != done_before:
            _redraw_views(screen)
        elif self.session is not None and self.session.take_new_frame():
            _redraw_views(screen)
        return True

    def _release_bake(self, bake):
        """Drain the job's writer and free its ring (kept alive, never freed, after a fatal CUDA error)."""
        bake.store.close()
        if self.restart_required:
            _QUARANTINE.append(bake)

    def _finish_bake(self, report: Report):
        from .cache import bake as cache_bake
        bake, self.bake = self.bake, None
        self._release_bake(bake)
        span = f"frames {bake.plan.first}-{bake.plan.first + bake.frames_done - 1}"
        if bake.state == cache_bake.DONE:
            self.bake_result = f"Baked {span} ({bake.frames_done} frames)"
            report({'INFO'}, "WarpSPH " + self.bake_result)
        elif bake.state == cache_bake.CANCELLED:
            self.bake_result = f"Bake cancelled: {bake.frames_done} frames cached ({span}); Resume continues"
            report({'WARNING'}, "WarpSPH " + self.bake_result)
        else:
            self.bake_result = f"Bake failed: {bake.error} ({bake.frames_done} frames cached)"
            report({'ERROR'}, "WarpSPH " + self.bake_result)
        if self.solver is not None:
            self.solver.substeps = self.scene.warp_sph.substeps
        self.paused = True  # keep the final state on screen; Resume continues the live view
        self._timeline_rebuild = True  # bake used this solver; replay before returning to live timeline control

    def _discard_bake(self):
        """Teardown path (stop, file load, unregister): leave the cache as a whole prefix and free the ring."""
        bake, self.bake = self.bake, None
        if bake is not None:
            bake.cancel()
            self._release_bake(bake)
            self.bake_result = f"Bake stopped: {bake.frames_done} frames cached"

    def stop(self, context=None):
        """Idempotent teardown for stop, cancel, unregister, file load and viewport loss."""
        context = context or getattr(bpy, "context", None)
        self.running = False
        self.paused = False
        self.step_once = False
        self.token += 1
        from . import native_output
        native_output.stop(self)
        self._discard_bake()
        self.tracker = None
        if active() is None:
            _watch_depsgraph(False)
        if self.timer is not None:
            wm = getattr(context, "window_manager", None)
            if wm is not None:
                try:
                    wm.event_timer_remove(self.timer)
                except (ReferenceError, RuntimeError, ValueError):
                    pass  # already freed with its window
            self.timer = None
        if self.draw_handle:
            bpy.types.SpaceView3D.draw_handler_remove(self.draw_handle, 'WINDOW')
            self.draw_handle = None
        session, solver = self.session, self.solver
        self.session = None
        self.solver = None
        if session is not None:
            if self.restart_required:
                _QUARANTINE.append(session)  # no speculative CUDA cleanup after a fatal error
            else:
                self._retire(session)
        if self.restart_required and solver is not None:
            _QUARANTINE.append(solver)  # dropping it would free CUDA allocations
        if self.gl_buf:
            if runtime.cleanup_viewport_renderer is not None:
                runtime.cleanup_viewport_renderer()
            self.gl_buf.destroy()
            self.gl_buf = None
        _redraw_views(getattr(context, "screen", None))

    def dispose(self, context=None):
        """Stop and forget this session; get() then hands its scene a fresh one."""
        self.stop(context)
        for key, session in list(_SESSIONS.items()):
            if session is self:
                del _SESSIONS[key]
        self.scene = None


# -- change detection (P2.9) -------------------------------------------------------------------------

def _on_depsgraph_update(_scene=None, depsgraph=None):
    """depsgraph_update_post, installed only while a run is active. Records changes; never raises."""
    session = active()
    if session is not None:
        try:
            session.note_updates(getattr(depsgraph, "updates", ()) or ())
        except Exception:  # pragma: no cover - a handler must never raise into Blender
            _LOG.exception("WarpSPH change detection failed")


def _watch_depsgraph(on: bool):
    hooks = getattr(getattr(getattr(bpy, "app", None), "handlers", None), "depsgraph_update_post", None)
    if hooks is None:
        return
    if on and _on_depsgraph_update not in hooks:
        hooks.append(_on_depsgraph_update)
    while not on and _on_depsgraph_update in hooks:
        hooks.remove(_on_depsgraph_update)


def _find_scene(key):
    """The scene with session_uid (or name) ``key``, or None."""
    for scene in getattr(getattr(bpy, "data", None), "scenes", ()) or ():
        if live_edits.uid(scene) == key:
            return scene
    return None


def before_undo():
    """undo_pre / redo_pre: a bake reads only the scene as it was when it began, so undo cancels it
    (frames already captured are kept); the live run itself continues."""
    for session in sessions():
        if session.bake is not None:
            session.cancel_bake()


def after_undo():
    for session in sessions():
        if session.running:
            session.after_undo()


# -- per-scene registry ------------------------------------------------------------------------------

_SESSIONS: dict[int, SimSession] = {}


def _scene_key(scene) -> int:
    as_pointer = getattr(scene, "as_pointer", None)
    return as_pointer() if as_pointer is not None else id(scene)


def _alive(scene) -> bool:
    try:
        getattr(scene, "name", None)  # ReferenceError once Blender freed it (file load, scene delete)
    except ReferenceError:
        return False
    return scene is not None


def _is_scene(stored, scene) -> bool:
    """The stored scene is still alive and is ``scene`` (a freed scene's address can be reused)."""
    return _alive(stored) and stored == scene


def scene_name(scene) -> str:
    try:
        return str(getattr(scene, "name", "") or "")
    except ReferenceError:
        return ""


def get(scene) -> SimSession:
    """The session of ``scene``, created on first use."""
    key = _scene_key(scene)
    session = _SESSIONS.get(key)
    if session is None or (not session.running and session.solver is None and not _is_scene(session.scene, scene)):
        for stale_key, stale in list(_SESSIONS.items()):  # idle sessions of freed scenes (e.g. after a file load)
            if not stale.running and stale.solver is None and not _alive(stale.scene):
                del _SESSIONS[stale_key]
        session = _SESSIONS[key] = SimSession(scene)
    return session


def active() -> SimSession | None:
    """The running session, if any (at most one per process)."""
    return next((s for s in _SESSIONS.values() if s.running), None)


def sessions() -> list[SimSession]:
    return list(_SESSIONS.values())


def stop_all(context=None):
    for session in sessions():
        session.stop(context)


def dispose_all(context=None):
    for session in sessions():
        session.dispose(context)
