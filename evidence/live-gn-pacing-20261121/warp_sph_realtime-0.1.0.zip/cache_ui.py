"""Record / bake UI (P1.6, P2.2): operators and the sub-panel under the main WarpSPH panel.

Thin: the bake itself is ``SimSession.begin_bake`` (driven by the session's modal timer in small chunks),
the files are ``cache.disk.DiskCache`` and playback is ``cache.blender_adapter``. This module only turns
button presses into those calls and shows their state.
"""
from __future__ import annotations

import importlib
import time

import bpy

from . import props, sdk_snapshot_ui, sim_session


def _adapter():
    return importlib.import_module(".cache.blender_adapter", __package__)


def _disk():
    return importlib.import_module(".cache.disk", __package__)


def _output():
    return importlib.import_module(".cache.output", __package__)


def _blender_output():
    return importlib.import_module(".cache.blender_output", __package__)


def _session(context) -> sim_session.SimSession:
    return sim_session.get(context.scene)


def _cache_dir(scene):
    return _adapter().cache_dir(scene)


def _human(size: float) -> str:
    for unit in ("B", "KB", "MB", "GB"):
        if size < 1024.0 or unit == "GB":
            return f"{size:.0f} {unit}" if unit == "B" else f"{size:.1f} {unit}"
        size /= 1024.0
    return ""


_status_memo: dict = {}


def cache_status(directory, max_age: float = 1.0):
    """(cached range or None, size in bytes) of a cache folder; memoised briefly because panels redraw often."""
    now = time.monotonic()
    memo = _status_memo.get(str(directory))
    if memo is not None and now - memo[0] < max_age:
        return memo[1]
    disk = _disk().DiskCache(directory)
    try:
        value = (disk.cached_range(), disk.size_bytes())
    except _disk().CacheError:
        value = (None, 0)
    _status_memo[str(directory)] = (now, value)
    return value


def _forget_status():
    _status_memo.clear()


def _frame_list(frames, limit: int = 5) -> str:
    shown = ", ".join(str(f) for f in frames[:limit])
    return shown + (", ..." if len(frames) > limit else "")


def particle_estimate(scene, session) -> int:
    """Particles a bake of this scene would have: the running solver's count, else the settings' estimate."""
    if session.solver is not None:
        return int(session.solver.num_particles)
    settings = scene.warp_sph
    if settings.scene_source != 'CUSTOM':
        return int(settings.particle_count)
    try:
        api = importlib.import_module(".scene.blender_scene", __package__)
        return props.custom_particle_estimate(api.objects_by_role(scene).get("FLUID", []), settings.particle_spacing)
    except Exception:
        return 0


class WM_OT_warp_sph_bake(bpy.types.Operator):
    bl_idname = "wm.warp_sph_bake"
    bl_label = "Bake"
    bl_description = ("Simulate the frame range from the initial state and save every frame to the cache folder "
                      "(starts the simulation if needed). Resume continues after the last cached frame")

    resume: bpy.props.BoolProperty(default=False, options={'SKIP_SAVE'})

    @classmethod
    def poll(cls, context):
        return _session(context).bake is None and getattr(_session(context), 'native_bake', None) is None

    def invoke(self, context, event):
        if getattr(context.scene.warp_sph, "use_shared_sdk", False):
            return self.execute(context)
        if not self.resume:
            # Count frame files, not the manifest's range: a fresh bake deletes every frame file, also when the
            # manifest is missing or unreadable.
            frames = _disk().DiskCache(_cache_dir(context.scene)).frames()
            if frames:
                return context.window_manager.invoke_confirm(
                    self, event, message=f"Replace the {len(frames)} cached frames?")
        return self.execute(context)

    def execute(self, context):
        session = _session(context)
        settings = context.scene.warp_sph
        if not session.running:
            other = sim_session.active()
            if other is not None:
                self.report({'ERROR'}, "WarpSPH is already running in another scene; stop it first")
                return {'CANCELLED'}
            try:
                bpy.ops.wm.warp_sph_start()
            except RuntimeError as exc:
                self.report({'ERROR'}, f"WarpSPH cannot start: {exc}")
                return {'CANCELLED'}
            if not session.running:
                return {'CANCELLED'}  # Start reported why
        _forget_status()
        started = session.begin_bake(
            context, self.report, first=settings.bake_start, last=settings.bake_end, resume=self.resume)
        return {'FINISHED'} if started else {'CANCELLED'}


class WM_OT_warp_sph_bake_cancel(bpy.types.Operator):
    bl_idname = "wm.warp_sph_bake_cancel"
    bl_label = "Cancel Bake"
    bl_description = "Stop baking. The frames saved so far stay valid and Resume continues from them"

    @classmethod
    def poll(cls, context):
        return _session(context).bake is not None or getattr(_session(context), 'native_bake', None) is not None

    def execute(self, context):
        _session(context).cancel_bake()
        return {'FINISHED'}


class WM_OT_warp_sph_cache_invalidate(bpy.types.Operator):
    bl_idname = "wm.warp_sph_cache_invalidate"
    bl_label = "Invalidate From Current Frame"
    bl_description = ("Delete the cached frames from the current frame onward, so a Resume re-simulates them "
                      "(for example after changing a setting that applies from that frame)")

    @classmethod
    def poll(cls, context):
        return _session(context).bake is None and getattr(_session(context), 'native_bake', None) is None

    def execute(self, context):
        disk = _disk().DiskCache(_cache_dir(context.scene))
        try:
            removed = disk.invalidate_from(context.scene.frame_current)
        except _disk().CacheError as exc:
            self.report({'ERROR'}, str(exc))
            return {'CANCELLED'}
        _forget_status()
        self.report({'INFO'}, f"Invalidated {removed} cached frames from frame {context.scene.frame_current}")
        return {'FINISHED'}


class WM_OT_warp_sph_cache_clear(bpy.types.Operator):
    bl_idname = "wm.warp_sph_cache_clear"
    bl_label = "Delete Cache"
    bl_description = "Delete every cached frame of this scene"

    @classmethod
    def poll(cls, context):
        return _session(context).bake is None and getattr(_session(context), 'native_bake', None) is None

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event, message="Delete all cached frames of this scene?")

    def execute(self, context):
        try:
            removed = _disk().DiskCache(_cache_dir(context.scene)).clear()
        except _disk().CacheError as exc:
            self.report({'ERROR'}, str(exc))
            return {'CANCELLED'}
        _forget_status()
        self.report({'INFO'}, f"Deleted {removed} cached frames")
        return {'FINISHED'}


class WM_OT_warp_sph_cache_playback(bpy.types.Operator):
    bl_idname = "wm.warp_sph_cache_playback"
    bl_label = "Show Cache"
    bl_description = ("Add a point cloud object that follows the timeline with the cached frames "
                      "(renders in Cycles; has velocity, id and age attributes)")

    show: bpy.props.BoolProperty(default=True, options={'SKIP_SAVE'})

    def execute(self, context):
        adapter = _adapter()
        scene = context.scene
        if not self.show:
            _blender_output().remove_mesh_object(scene)  # the meshing object reads the point cloud
            adapter.remove_playback_object(scene)
            return {'FINISHED'}
        cached, _size = cache_status(_cache_dir(scene), max_age=0.0)
        if cached is None:
            self.report({'ERROR'}, "Nothing is cached yet: bake first")
            return {'CANCELLED'}
        adapter.ensure_playback_object(scene)
        try:
            adapter.show_frame(scene, scene.frame_current)
        except _disk().CacheError as exc:
            self.report({'ERROR'}, str(exc))
            return {'CANCELLED'}
        return {'FINISHED'}


def _ensure_playback(context):
    """The scene's playback point cloud showing the current frame (created if missing); raises CacheError."""
    adapter = _adapter()
    scene = context.scene
    obj = adapter.ensure_playback_object(scene)
    adapter.show_frame(scene, scene.frame_current)
    return obj


class WM_OT_warp_sph_cache_mesh(bpy.types.Operator):
    bl_idname = "wm.warp_sph_cache_mesh"
    bl_label = "Add Mesh Preset"
    bl_description = ("Add a mesh object that surfaces the cache point cloud with Geometry Nodes "
                      "(points to volume to mesh). Radius, voxel size, threshold and smoothing are modifier inputs")

    show: bpy.props.BoolProperty(default=True, options={'SKIP_SAVE'})

    def execute(self, context):
        scene = context.scene
        blender_output = _blender_output()
        if not self.show:
            blender_output.remove_mesh_object(scene)
            return {'FINISHED'}
        directory = _cache_dir(scene)
        cached, _size = cache_status(directory, max_age=0.0)
        if cached is None:
            self.report({'ERROR'}, "Nothing is cached yet: bake first")
            return {'CANCELLED'}
        try:
            cloud = _ensure_playback(context)
            output = _output()
            manifest = _disk().DiskCache(directory).manifest()
            settings = scene.warp_sph
            spacing = output.particle_spacing(manifest, settings.particle_spacing, settings.particle_radius)
            blender_output.ensure_mesh_object(scene, cloud, output.meshing_defaults(spacing))
        except (_disk().CacheError, RuntimeError, TypeError) as exc:
            self.report({'ERROR'}, f"Cannot add the mesh preset: {exc}")
            return {'CANCELLED'}
        return {'FINISHED'}


class WM_OT_warp_sph_cache_export(bpy.types.Operator):
    bl_idname = "wm.warp_sph_cache_export"
    bl_label = "Export Meshed Sequence"
    bl_description = ("Export the meshed fluid over the baked frames as USD or Alembic "
                      "(adds the playback point cloud and mesh preset if missing)")

    filepath: bpy.props.StringProperty(subtype='FILE_PATH')
    filter_glob: bpy.props.StringProperty(default="*.usd;*.usdc;*.usda;*.abc", options={'HIDDEN'})
    format: bpy.props.EnumProperty(
        name="Format", items=(('USD', "USD", "Universal Scene Description (.usdc)"),
                              ('ALEMBIC', "Alembic", "Alembic (.abc)")), default='USD')

    @classmethod
    def poll(cls, context):
        return _session(context).bake is None and getattr(_session(context), 'native_bake', None) is None

    def invoke(self, context, event):
        if not self.filepath:
            scene = context.scene
            default = _cache_dir(scene).parent / bpy.path.clean_name(scene.name)
            self.filepath = str(_output().export_path(str(default), self.format))
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

    def execute(self, context):
        scene = context.scene
        output, blender_output = _output(), _blender_output()
        if not self.filepath:
            self.report({'ERROR'}, "Choose a file to export to")
            return {'CANCELLED'}
        cached, _size = cache_status(_cache_dir(scene), max_age=0.0)
        try:
            frames = output.export_frames(cached)  # only baked frames are exported
            mesh = blender_output.find_mesh_object(scene)
            if mesh is None:
                bpy.ops.wm.warp_sph_cache_mesh()
                mesh = blender_output.find_mesh_object(scene)
            if mesh is None:
                self.report({'ERROR'}, "The mesh preset could not be added")
                return {'CANCELLED'}
            directory = _cache_dir(scene)
            _adapter().clear_playback_failures(directory)
            target = blender_output.export_sequence(context, self.filepath, self.format, mesh, frames)
        except (ValueError, RuntimeError, _disk().CacheError) as exc:
            self.report({'ERROR'}, f"Export failed: {exc}")
            return {'CANCELLED'}
        held = sorted(f for f in _adapter().playback_failures(directory) if frames[0] <= f <= frames[1])
        if held:
            self.report({'WARNING'}, f"Exported to {target}, but {len(held)} cached frame(s) could not be read "
                                     f"({_frame_list(held)}) and repeat the frame before them: re-bake them")
            return {'FINISHED'}
        self.report({'INFO'}, f"Exported frames {frames[0]}-{frames[1]} to {target}")
        return {'FINISHED'}


class VIEW3D_PT_warp_sph_cache(bpy.types.Panel):
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "WarpSPH"
    bl_label = "Record / Bake Cache"
    bl_parent_id = "VIEW3D_PT_warp_sph"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        settings = scene.warp_sph
        session = _session(context)
        baking = session.bake
        cache_disk = _disk()
        directory = _cache_dir(scene)

        col = layout.column(align=True)
        col.enabled = baking is None
        col.prop(settings, "cache_dir")
        col.label(text=str(directory), icon='FILE_FOLDER')
        row = col.row(align=True)
        row.prop(settings, "bake_start")
        row.prop(settings, "bake_end")
        col.prop(settings, "bake_steps")

        frames = settings.bake_end - settings.bake_start + 1
        if frames < 1:
            layout.label(text="End must not be before Start", icon='ERROR')
        else:
            particles = particle_estimate(scene, session)
            need = cache_disk.estimate_bytes(particles, frames)
            free = cache_disk.free_bytes(directory)
            text = f"Size: {'~' if session.solver is None else ''}{_human(need)} ({frames} frames"
            text += f" x {_human(cache_disk.frame_bytes(particles))})"
            layout.label(text=text, icon='DISK_DRIVE')
            if free is not None and need > free:
                layout.label(text=f"Only {_human(free)} free on this drive", icon='ERROR')

        cached, size = cache_status(directory)
        if cached is not None:
            layout.label(text=f"Cached: frames {cached[0]}-{cached[1]} ({_human(size)})")
        else:
            layout.label(text="Cached: nothing")

        if baking is not None:
            layout.progress(factor=baking.fraction, type='BAR',
                            text=f"{baking.state.title()} {baking.frames_done}/{baking.plan.total}")
            eta = baking.eta_seconds()
            if eta is not None:
                layout.label(text=f"About {eta:.0f} s left")
            layout.operator("wm.warp_sph_bake_cancel", icon='CANCEL')
        else:
            if session.bake_result:
                layout.label(text=session.bake_result, icon='INFO')
            row = layout.row(align=True)
            row.operator("wm.warp_sph_bake", icon='REC').resume = False
            resumable = cached is not None and cached[1] < settings.bake_end
            sub = row.row(align=True)
            sub.enabled = resumable
            sub.operator("wm.warp_sph_bake", text="Resume", icon='PLAY').resume = True
            row = layout.row(align=True)
            row.enabled = cached is not None
            row.operator("wm.warp_sph_cache_invalidate", icon='TRASH')
            row.operator("wm.warp_sph_cache_clear", text="Delete", icon='X')

        row = layout.row(align=True)
        adapter = _adapter()
        if adapter.find_playback_object(scene) is None:
            row.enabled = cached is not None
            row.operator("wm.warp_sph_cache_playback", text="Show Cache as Point Cloud", icon='OUTLINER_OB_POINTCLOUD')
        else:
            row.operator("wm.warp_sph_cache_playback", text="Hide Cache", icon='HIDE_ON').show = False
            failed = adapter.playback_failures(directory).get(scene.frame_current)
            if failed:
                layout.label(text=f"Frame {scene.frame_current} not shown (an older frame is): {failed}", icon='ERROR')

        layout.separator()
        layout.label(text="Output")
        blender_output = _blender_output()
        mesh = blender_output.find_mesh_object(scene)
        row = layout.row(align=True)
        if mesh is None:
            row.enabled = cached is not None
            row.operator("wm.warp_sph_cache_mesh", text="Add Mesh Preset", icon='MOD_FLUIDSIM').show = True
        else:
            row.operator("wm.warp_sph_cache_mesh", text="Remove Mesh", icon='X').show = False
            col = layout.column(align=True)
            for name in ("Radius", "Voxel Size", "Threshold", "Smooth Iterations", "Material"):
                socket = blender_output.input_socket(mesh, name)
                if socket is not None:
                    col.prop(socket, "value", text=name)
        row = layout.row(align=True)
        row.enabled = cached is not None and baking is None
        row.operator("wm.warp_sph_cache_export", text="Export USD", icon='EXPORT').format = 'USD'
        row.operator("wm.warp_sph_cache_export", text="Export Alembic", icon='EXPORT').format = 'ALEMBIC'


CLASSES = (
    WM_OT_warp_sph_bake,
    WM_OT_warp_sph_bake_cancel,
    WM_OT_warp_sph_cache_invalidate,
    WM_OT_warp_sph_cache_clear,
    WM_OT_warp_sph_cache_playback,
    WM_OT_warp_sph_cache_mesh,
    WM_OT_warp_sph_cache_export,
    VIEW3D_PT_warp_sph_cache,
)


def register():
    """Register after the main panel: the cache panel is its sub-panel."""
    for cls in CLASSES:
        bpy.utils.register_class(cls)
    _adapter().register()
    sdk_snapshot_ui.register()


def unregister():
    sdk_snapshot_ui.unregister()
    _adapter().unregister()
    for cls in reversed(CLASSES):
        bpy.utils.unregister_class(cls)
    _forget_status()
